<template>
  <!-- 模板保持不变 -->
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const loading = ref(false)
const dialogVisible = ref(false)
const dialogType = ref('add')
const userFormRef = ref()  // 修改：重命名为 userFormRef
const total = ref(0)

const listQuery = reactive({
  page: 1,
  limit: 10,
  keyword: ''
})

const userList = ref([
  {
    id: 1,
    username: '张三',
    phone: '13800138000',
    email: 'zhangsan@example.com',
    status: 1,
    createTime: '2024-01-01 10:00:00'
  },
  {
    id: 2,
    username: '李四',
    phone: '13800138001',
    email: 'lisi@example.com',
    status: 0,
    createTime: '2024-01-02 11:00:00'
  }
])

// 修改：移除重复的 const userForm = reactive
const userFormData = reactive({  // 重命名为 userFormData
  id: null,
  username: '',
  phone: '',
  email: '',
  password: '',
  status: 1
})

const userRules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' }
  ],
  phone: [
    { required: true, message: '请输入手机号', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' }
  ],
  email: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '邮箱格式不正确', trigger: 'blur' }
  ]
}

onMounted(() => {
  getList()
})

const getList = () => {
  loading.value = true
  setTimeout(() => {
    total.value = 100
    loading.value = false
  }, 500)
}

const handleFilter = () => {
  listQuery.page = 1
  getList()
}

const handleAdd = () => {
  dialogType.value = 'add'
  Object.keys(userFormData).forEach(key => {
    userFormData[key] = ''
  })
  userFormData.status = 1
  dialogVisible.value = true
}

const handleEdit = (row) => {
  dialogType.value = 'edit'
  Object.assign(userFormData, row)
  dialogVisible.value = true
}

const handleDelete = (row) => {
  ElMessageBox.confirm('确定删除该用户吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    ElMessage.success('删除成功')
    getList()
  }).catch(() => {})
}

const handleSubmit = async () => {
  try {
    await userFormRef.value.validate()

    if (dialogType.value === 'add') {
      ElMessage.success('添加成功')
    } else {
      ElMessage.success('更新成功')
    }

    dialogVisible.value = false
    getList()
  } catch (error) {
    console.error('表单验证失败:', error)
  }
}
</script>

<style scoped>
/* 样式保持不变 */
</style>