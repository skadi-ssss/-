import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useAuthStore = defineStore('auth', () => {
    const token = ref(localStorage.getItem('token') || '')
    const user = ref(JSON.parse(localStorage.getItem('user') || 'null'))

    const isAuthenticated = computed(() => !!token.value)

    const login = async (username, password) => {
        // 模拟登录API调用
        return new Promise((resolve) => {
            setTimeout(() => {
                if (username === 'admin' && password === 'admin123') {
                    const mockToken = 'mock-jwt-token'
                    const mockUser = {
                        id: 1,
                        username: 'admin',
                        role: 'admin'
                    }

                    token.value = mockToken
                    user.value = mockUser

                    localStorage.setItem('token', mockToken)
                    localStorage.setItem('user', JSON.stringify(mockUser))

                    resolve(true)
                } else {
                    resolve(false)
                }
            }, 1000)
        })
    }

    const logout = () => {
        token.value = ''
        user.value = null
        localStorage.removeItem('token')
        localStorage.removeItem('user')
    }

    const checkAuth = () => {
        const storedToken = localStorage.getItem('token')
        const storedUser = localStorage.getItem('user')

        if (storedToken && storedUser) {
            token.value = storedToken
            user.value = JSON.parse(storedUser)
        }
    }

    return {
        token,
        user,
        isAuthenticated,
        login,
        logout,
        checkAuth
    }
})