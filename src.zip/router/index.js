import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/store/auth'

const routes = [
    {
        path: '/login',
        name: 'Login',
        component: () => import('@/views/Login.vue'),
        meta: { requiresAuth: false }
    },
    {
        path: '/',
        component: () => import('@/views/Layout.vue'),
        meta: { requiresAuth: true },
        children: [
            {
                path: '',
                name: 'Dashboard',
                component: () => import('@/views/dashboard/Index.vue')
            },
            // 用户信息管理
            {
                path: '/user/list',
                name: 'UserList',
                component: () => import('@/views/user/UserList.vue')
            },
            {
                path: '/user/feedback',
                name: 'Feedback',
                component: () => import('@/views/user/Feedback.vue')
            },
            {
                path: '/user/reservation',
                name: 'Reservation',
                component: () => import('@/views/user/Reservation.vue')
            },
            // 座位管理
            {
                path: '/seat/list',
                name: 'SeatList',
                component: () => import('@/views/seat/SeatList.vue')
            },
            // 数据分析
            {
                path: '/analysis',
                name: 'Analysis',
                component: () => import('@/views/analysis/Analysis.vue')
            },
            // 日志记录查询
            {
                path: '/log/user',
                name: 'UserLog',
                component: () => import('@/views/log/UserLog.vue')
            },
            {
                path: '/log/seat',
                name: 'SeatLog',
                component: () => import('@/views/log/SeatLog.vue')
            },
            {
                path: '/log/admin',
                name: 'AdminLog',
                component: () => import('@/views/log/AdminLog.vue')
            }
        ]
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

router.beforeEach((to, from, next) => {
    const authStore = useAuthStore()

    if (to.meta.requiresAuth && !authStore.isAuthenticated) {
        next('/login')
    } else if (to.path === '/login' && authStore.isAuthenticated) {
        next('/')
    } else {
        next()
    }
})

export default router